import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import db from './database.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../dist')));

// Email transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || 'huzaifaabass7@gmail.com',
    pass: process.env.EMAIL_PASS || ''
  }
});

// Helper function to send emails
const sendEmail = async (to, subject, html) => {
  try {
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    await transporter.sendMail({
      from: `"${settings.store_name}" <${settings.email}>`,
      to,
      subject,
      html
    });
    return true;
  } catch (error) {
    console.error('Email sending failed:', error);
    return false;
  }
};

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid token.' });
  }
};

const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
};

// ============ SETTINGS ROUTES ============

// Get store settings
app.get('/api/settings', (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update store settings (admin only)
app.put('/api/settings', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { store_name, phone, email, address, currency } = req.body;
    
    const stmt = db.prepare(`
      UPDATE settings 
      SET store_name = ?, phone = ?, email = ?, address = ?, currency = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
    `);
    
    stmt.run(store_name, phone, email, address, currency);
    
    const updated = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ AUTH ROUTES ============

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }
    
    // Check if user exists
    const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Insert user
    const stmt = db.prepare(`
      INSERT INTO users (name, email, phone, password, role)
      VALUES (?, ?, ?, ?, 'customer')
    `);
    
    const result = stmt.run(name, email, phone || '', hashedPassword);
    
    // Generate token
    const token = jwt.sign(
      { userId: result.lastInsertRowid, email, role: 'customer' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // Send welcome email
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    await sendEmail(
      email,
      `Welcome to ${settings.store_name}!`,
      `<h2>Welcome ${name}!</h2><p>Thank you for creating an account with ${settings.store_name}. Start shopping for the latest smartphones today!</p>`
    );
    
    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: result.lastInsertRowid,
        name,
        email,
        phone: phone || '',
        role: 'customer'
      }
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // Find user
    const user = db.prepare('SELECT * FROM users WHERE email = ? AND is_active = 1').get(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Verify password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Generate token
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get current user
app.get('/api/auth/me', authenticateToken, (req, res) => {
  try {
    const user = db.prepare('SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?').get(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ PHONE ROUTES ============

// Get all phones (with optional filters)
app.get('/api/phones', (req, res) => {
  try {
    const { brand, search, featured, min_price, max_price } = req.query;
    
    let query = 'SELECT * FROM phones WHERE is_active = 1';
    const params = [];
    
    if (brand) {
      query += ' AND brand = ?';
      params.push(brand);
    }
    
    if (search) {
      query += ' AND (name LIKE ? OR brand LIKE ? OR model LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (featured === 'true') {
      query += ' AND is_featured = 1';
    }
    
    if (min_price) {
      query += ' AND price >= ?';
      params.push(min_price);
    }
    
    if (max_price) {
      query += ' AND price <= ?';
      params.push(max_price);
    }
    
    query += ' ORDER BY is_featured DESC, created_at DESC';
    
    const phones = db.prepare(query).all(...params);
    
    // Parse specifications JSON
    const parsedPhones = phones.map(phone => ({
      ...phone,
      specifications: phone.specifications ? JSON.parse(phone.specifications) : null
    }));
    
    res.json(parsedPhones);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single phone
app.get('/api/phones/:id', (req, res) => {
  try {
    const phone = db.prepare('SELECT * FROM phones WHERE id = ? AND is_active = 1').get(req.params.id);
    
    if (!phone) {
      return res.status(404).json({ error: 'Phone not found' });
    }
    
    res.json({
      ...phone,
      specifications: phone.specifications ? JSON.parse(phone.specifications) : null
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create phone (admin only)
app.post('/api/phones', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { name, brand, model, description, price, original_price, stock, image_url, specifications, is_featured } = req.body;
    
    if (!name || !brand || !model || !price) {
      return res.status(400).json({ error: 'Name, brand, model and price are required' });
    }
    
    const stmt = db.prepare(`
      INSERT INTO phones (name, brand, model, description, price, original_price, stock, image_url, specifications, is_featured)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const result = stmt.run(
      name,
      brand,
      model,
      description || '',
      price,
      original_price || null,
      stock || 0,
      image_url || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500',
      specifications ? JSON.stringify(specifications) : null,
      is_featured ? 1 : 0
    );
    
    const phone = db.prepare('SELECT * FROM phones WHERE id = ?').get(result.lastInsertRowid);
    
    res.status(201).json({
      ...phone,
      specifications: phone.specifications ? JSON.parse(phone.specifications) : null
    });
  } catch (error) {
    console.error('Create phone error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Update phone (admin only)
app.put('/api/phones/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { name, brand, model, description, price, original_price, stock, image_url, specifications, is_featured, is_active } = req.body;
    
    const stmt = db.prepare(`
      UPDATE phones 
      SET name = ?, brand = ?, model = ?, description = ?, price = ?, original_price = ?, 
          stock = ?, image_url = ?, specifications = ?, is_featured = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    stmt.run(
      name,
      brand,
      model,
      description,
      price,
      original_price || null,
      stock || 0,
      image_url || null,
      specifications ? JSON.stringify(specifications) : null,
      is_featured ? 1 : 0,
      is_active !== undefined ? (is_active ? 1 : 0) : 1,
      req.params.id
    );
    
    const phone = db.prepare('SELECT * FROM phones WHERE id = ?').get(req.params.id);
    
    if (!phone) {
      return res.status(404).json({ error: 'Phone not found' });
    }
    
    res.json({
      ...phone,
      specifications: phone.specifications ? JSON.parse(phone.specifications) : null
    });
  } catch (error) {
    console.error('Update phone error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Delete phone (admin only)
app.delete('/api/phones/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const stmt = db.prepare('UPDATE phones SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
    stmt.run(req.params.id);
    
    res.json({ message: 'Phone deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all brands
app.get('/api/brands', (req, res) => {
  try {
    const brands = db.prepare('SELECT DISTINCT brand FROM phones WHERE is_active = 1 ORDER BY brand').all();
    res.json(brands.map(b => b.brand));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ CART ROUTES ============

// Get cart
app.get('/api/cart', authenticateToken, (req, res) => {
  try {
    const cartItems = db.prepare(`
      SELECT c.*, p.name, p.price, p.image_url, p.stock
      FROM cart c
      JOIN phones p ON c.phone_id = p.id
      WHERE c.user_id = ?
    `).all(req.user.userId);
    
    res.json(cartItems);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add to cart
app.post('/api/cart', authenticateToken, (req, res) => {
  try {
    const { phone_id, quantity = 1 } = req.body;
    
    if (!phone_id) {
      return res.status(400).json({ error: 'Phone ID is required' });
    }
    
    // Check stock
    const phone = db.prepare('SELECT stock FROM phones WHERE id = ?').get(phone_id);
    if (!phone) {
      return res.status(404).json({ error: 'Phone not found' });
    }
    
    if (phone.stock < quantity) {
      return res.status(400).json({ error: 'Insufficient stock' });
    }
    
    // Check if already in cart
    const existing = db.prepare('SELECT * FROM cart WHERE user_id = ? AND phone_id = ?').get(req.user.userId, phone_id);
    
    if (existing) {
      // Update quantity
      const newQuantity = existing.quantity + quantity;
      if (newQuantity > phone.stock) {
        return res.status(400).json({ error: 'Insufficient stock' });
      }
      db.prepare('UPDATE cart SET quantity = ? WHERE id = ?').run(newQuantity, existing.id);
    } else {
      // Insert new
      db.prepare('INSERT INTO cart (user_id, phone_id, quantity) VALUES (?, ?, ?)').run(req.user.userId, phone_id, quantity);
    }
    
    res.json({ message: 'Added to cart' });
  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Update cart quantity
app.put('/api/cart/:id', authenticateToken, (req, res) => {
  try {
    const { quantity } = req.body;
    
    // Verify cart item belongs to user
    const cartItem = db.prepare('SELECT * FROM cart WHERE id = ? AND user_id = ?').get(req.params.id, req.user.userId);
    if (!cartItem) {
      return res.status(404).json({ error: 'Cart item not found' });
    }
    
    // Check stock
    const phone = db.prepare('SELECT stock FROM phones WHERE id = ?').get(cartItem.phone_id);
    if (quantity > phone.stock) {
      return res.status(400).json({ error: 'Insufficient stock' });
    }
    
    if (quantity <= 0) {
      db.prepare('DELETE FROM cart WHERE id = ?').run(req.params.id);
    } else {
      db.prepare('UPDATE cart SET quantity = ? WHERE id = ?').run(quantity, req.params.id);
    }
    
    res.json({ message: 'Cart updated' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Remove from cart
app.delete('/api/cart/:id', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM cart WHERE id = ? AND user_id = ?').run(req.params.id, req.user.userId);
    res.json({ message: 'Removed from cart' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Clear cart
app.delete('/api/cart', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM cart WHERE user_id = ?').run(req.user.userId);
    res.json({ message: 'Cart cleared' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ ORDER ROUTES ============

// Create order
app.post('/api/orders', authenticateToken, async (req, res) => {
  try {
    const { customer_name, customer_email, customer_phone, shipping_address, items, total_amount } = req.body;
    
    if (!customer_name || !customer_email || !customer_phone || !shipping_address || !items || items.length === 0) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    
    // Generate order number
    const orderNumber = 'ORD-' + Date.now().toString(36).toUpperCase();
    
    // Create order
    const orderStmt = db.prepare(`
      INSERT INTO orders (order_number, user_id, customer_name, customer_email, customer_phone, shipping_address, total_amount)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    
    const orderResult = orderStmt.run(
      orderNumber,
      req.user.userId,
      customer_name,
      customer_email,
      customer_phone,
      shipping_address,
      total_amount
    );
    
    const orderId = orderResult.lastInsertRowid;
    
    // Add order items and update stock
    const itemStmt = db.prepare(`
      INSERT INTO order_items (order_id, phone_id, quantity, unit_price, total_price)
      VALUES (?, ?, ?, ?, ?)
    `);
    
    const updateStockStmt = db.prepare('UPDATE phones SET stock = stock - ? WHERE id = ?');
    
    for (const item of items) {
      // Check stock again
      const phone = db.prepare('SELECT stock, price FROM phones WHERE id = ?').get(item.phone_id);
      if (!phone || phone.stock < item.quantity) {
        // Rollback order
        db.prepare('DELETE FROM orders WHERE id = ?').run(orderId);
        return res.status(400).json({ error: `Insufficient stock for item ${item.phone_id}` });
      }
      
      itemStmt.run(orderId, item.phone_id, item.quantity, item.unit_price, item.total_price);
      updateStockStmt.run(item.quantity, item.phone_id);
    }
    
    // Clear cart
    db.prepare('DELETE FROM cart WHERE user_id = ?').run(req.user.userId);
    
    // Get order details
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    
    // Send email notification
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    await sendEmail(
      customer_email,
      `Order Confirmation - ${orderNumber}`,
      `
        <h2>Thank you for your order!</h2>
        <p>Your order number is: <strong>${orderNumber}</strong></p>
        <p>Total Amount: ${settings.currency} ${total_amount.toLocaleString()}</p>
        <p>We will notify you once payment is confirmed.</p>
        <p><a href="${process.env.BASE_URL || ''}/track">Track your order here</a></p>
      `
    );
    
    res.status(201).json({
      message: 'Order created successfully',
      order
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get user orders
app.get('/api/orders', authenticateToken, (req, res) => {
  try {
    const orders = db.prepare(`
      SELECT o.*, 
        (SELECT json_group_array(
          json_object('id', oi.id, 'phone_id', oi.phone_id, 'quantity', oi.quantity, 
                      'unit_price', oi.unit_price, 'total_price', oi.total_price,
                      'phone_name', p.name, 'phone_image', p.image_url)
        ) FROM order_items oi 
        JOIN phones p ON oi.phone_id = p.id 
        WHERE oi.order_id = o.id) as items
      FROM orders o
      WHERE o.user_id = ?
      ORDER BY o.created_at DESC
    `).all(req.user.userId);
    
    res.json(orders.map(order => ({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    })));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single order
app.get('/api/orders/:id', authenticateToken, (req, res) => {
  try {
    const order = db.prepare(`
      SELECT o.*, 
        (SELECT json_group_array(
          json_object('id', oi.id, 'phone_id', oi.phone_id, 'quantity', oi.quantity, 
                      'unit_price', oi.unit_price, 'total_price', oi.total_price,
                      'phone_name', p.name, 'phone_image', p.image_url)
        ) FROM order_items oi 
        JOIN phones p ON oi.phone_id = p.id 
        WHERE oi.order_id = o.id) as items
      FROM orders o
      WHERE o.id = ? AND (o.user_id = ? OR ? = 'admin')
    `).get(req.params.id, req.user.userId, req.user.role);
    
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Track order (public)
app.get('/api/track/:orderNumber', (req, res) => {
  try {
    const order = db.prepare(`
      SELECT o.*, 
        (SELECT json_group_array(
          json_object('id', oi.id, 'phone_id', oi.phone_id, 'quantity', oi.quantity, 
                      'unit_price', oi.unit_price, 'total_price', oi.total_price,
                      'phone_name', p.name, 'phone_image', p.image_url)
        ) FROM order_items oi 
        JOIN phones p ON oi.phone_id = p.id 
        WHERE oi.order_id = o.id) as items
      FROM orders o
      WHERE o.order_number = ?
    `).get(req.params.orderNumber);
    
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update order status (admin only)
app.put('/api/orders/:id/status', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { order_status, payment_status } = req.body;
    
    const stmt = db.prepare(`
      UPDATE orders 
      SET order_status = COALESCE(?, order_status), 
          payment_status = COALESCE(?, payment_status),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    
    stmt.run(order_status, payment_status, req.params.id);
    
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
    
    // Send email notification if payment is confirmed
    if (payment_status === 'paid') {
      const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
      sendEmail(
        order.customer_email,
        `Payment Confirmed - ${order.order_number}`,
        `
          <h2>Payment Confirmed!</h2>
          <p>Your payment for order <strong>${order.order_number}</strong> has been received.</p>
          <p>Amount: ${settings.currency} ${order.total_amount.toLocaleString()}</p>
          <p>Your order is now being processed.</p>
        `
      );
    }
    
    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all orders (admin only)
app.get('/api/admin/orders', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { status, payment_status } = req.query;
    
    let query = `
      SELECT o.*, u.name as user_name,
        (SELECT json_group_array(
          json_object('id', oi.id, 'phone_id', oi.phone_id, 'quantity', oi.quantity, 
                      'unit_price', oi.unit_price, 'total_price', oi.total_price,
                      'phone_name', p.name, 'phone_image', p.image_url)
        ) FROM order_items oi 
        JOIN phones p ON oi.phone_id = p.id 
        WHERE oi.order_id = o.id) as items
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      WHERE 1=1
    `;
    const params = [];
    
    if (status) {
      query += ' AND o.order_status = ?';
      params.push(status);
    }
    
    if (payment_status) {
      query += ' AND o.payment_status = ?';
      params.push(payment_status);
    }
    
    query += ' ORDER BY o.created_at DESC';
    
    const orders = db.prepare(query).all(...params);
    
    res.json(orders.map(order => ({
      ...order,
      items: order.items ? JSON.parse(order.items) : []
    })));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ ADMIN ANALYTICS ============

// Get admin dashboard analytics
app.get('/api/admin/analytics', authenticateToken, requireAdmin, (req, res) => {
  try {
    // Total revenue (paid orders)
    const revenueResult = db.prepare(`
      SELECT COALESCE(SUM(total_amount), 0) as total_revenue 
      FROM orders 
      WHERE payment_status = 'paid'
    `).get();
    
    // Total orders
    const ordersResult = db.prepare('SELECT COUNT(*) as total_orders FROM orders').get();
    
    // Today's orders
    const todayOrdersResult = db.prepare(`
      SELECT COUNT(*) as today_orders 
      FROM orders 
      WHERE DATE(created_at) = DATE('now')
    `).get();
    
    // Today's revenue
    const todayRevenueResult = db.prepare(`
      SELECT COALESCE(SUM(total_amount), 0) as today_revenue 
      FROM orders 
      WHERE payment_status = 'paid' AND DATE(created_at) = DATE('now')
    `).get();
    
    // Low stock alerts
    const lowStockResult = db.prepare(`
      SELECT COUNT(*) as low_stock_count 
      FROM phones 
      WHERE stock < 5 AND is_active = 1
    `).get();
    
    // Total products
    const productsResult = db.prepare(`
      SELECT COUNT(*) as total_products 
      FROM phones 
      WHERE is_active = 1
    `).get();
    
    // Recent orders
    const recentOrders = db.prepare(`
      SELECT o.*, u.name as user_name
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      ORDER BY o.created_at DESC
      LIMIT 5
    `).all();
    
    // Sales by month (last 6 months)
    const salesByMonth = db.prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as month,
        COUNT(*) as order_count,
        COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN total_amount ELSE 0 END), 0) as revenue
      FROM orders
      WHERE created_at >= date('now', '-6 months')
      GROUP BY strftime('%Y-%m', created_at)
      ORDER BY month DESC
    `).all();
    
    // Top selling products
    const topProducts = db.prepare(`
      SELECT 
        p.name,
        p.image_url,
        SUM(oi.quantity) as total_sold,
        SUM(oi.total_price) as total_revenue
      FROM order_items oi
      JOIN phones p ON oi.phone_id = p.id
      JOIN orders o ON oi.order_id = o.id
      WHERE o.payment_status = 'paid'
      GROUP BY oi.phone_id
      ORDER BY total_sold DESC
      LIMIT 5
    `).all();
    
    res.json({
      totalRevenue: revenueResult.total_revenue,
      totalOrders: ordersResult.total_orders,
      todayOrders: todayOrdersResult.today_orders,
      todayRevenue: todayRevenueResult.today_revenue,
      lowStockCount: lowStockResult.low_stock_count,
      totalProducts: productsResult.total_products,
      recentOrders,
      salesByMonth,
      topProducts
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get low stock products
app.get('/api/admin/low-stock', authenticateToken, requireAdmin, (req, res) => {
  try {
    const phones = db.prepare(`
      SELECT * FROM phones 
      WHERE stock < 5 AND is_active = 1
      ORDER BY stock ASC
    `).all();
    
    res.json(phones.map(phone => ({
      ...phone,
      specifications: phone.specifications ? JSON.parse(phone.specifications) : null
    })));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ FLUTTERWAVE PAYMENT ============

// Initialize Flutterwave payment
app.post('/api/payment/initialize', authenticateToken, async (req, res) => {
  try {
    const { order_id, phone_number, payment_method } = req.body;
    
    const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(order_id, req.user.userId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    
    // Generate transaction reference
    const txRef = 'TX-' + uuidv4();
    
    // Update order with transaction reference
    db.prepare('UPDATE orders SET flutterwave_tx_ref = ? WHERE id = ?').run(txRef, order_id);
    
    // Return payment initialization data
    res.json({
      tx_ref: txRef,
      amount: order.total_amount,
      currency: settings.currency || 'UGX',
      email: order.customer_email,
      phone_number: phone_number || order.customer_phone,
      payment_options: 'mobilemoneyuganda',
      customer: {
        email: order.customer_email,
        phone_number: phone_number || order.customer_phone,
        name: order.customer_name
      },
      customizations: {
        title: settings.store_name,
        description: `Payment for order ${order.order_number}`,
        logo: ''
      },
      public_key: process.env.FLUTTERWAVE_PUBLIC_KEY || ''
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Verify Flutterwave payment (webhook)
app.post('/api/payment/verify', async (req, res) => {
  try {
    const { transaction_id, tx_ref, status } = req.body;
    
    if (status === 'successful') {
      // Update order status
      db.prepare(`
        UPDATE orders 
        SET payment_status = 'paid', order_status = 'processing', updated_at = CURRENT_TIMESTAMP
        WHERE flutterwave_tx_ref = ?
      `).run(tx_ref);
      
      const order = db.prepare('SELECT * FROM orders WHERE flutterwave_tx_ref = ?').get(tx_ref);
      
      if (order) {
        // Send confirmation email
        const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
        sendEmail(
          order.customer_email,
          `Payment Confirmed - Order ${order.order_number}`,
          `
            <h2>Payment Confirmed!</h2>
            <p>Your payment for order <strong>${order.order_number}</strong> has been received.</p>
            <p>Amount: ${settings.currency} ${order.total_amount.toLocaleString()}</p>
            <p>Your order is now being processed.</p>
          `
        );
      }
    }
    
    res.json({ message: 'Payment verified' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ INVOICE GENERATION ============

// Generate invoice HTML
app.get('/api/invoice/:orderId', authenticateToken, async (req, res) => {
  try {
    const order = db.prepare(`
      SELECT o.*, 
        (SELECT json_group_array(
          json_object('id', oi.id, 'phone_id', oi.phone_id, 'quantity', oi.quantity, 
                      'unit_price', oi.unit_price, 'total_price', oi.total_price,
                      'phone_name', p.name, 'phone_image', p.image_url)
        ) FROM order_items oi 
        JOIN phones p ON oi.phone_id = p.id 
        WHERE oi.order_id = o.id) as items
      FROM orders o
      WHERE o.id = ? AND (o.user_id = ? OR ? = 'admin')
    `).get(req.params.orderId, req.user.userId, req.user.role);
    
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get();
    const items = order.items ? JSON.parse(order.items) : [];
    
    const invoiceHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Invoice - ${order.order_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #333; background: #f8fafc; }
          .invoice-container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 3px solid #2563eb; padding-bottom: 20px; }
          .header h1 { color: #2563eb; font-size: 32px; margin-bottom: 5px; }
          .header p { color: #666; margin-top: 5px; font-size: 14px; }
          .invoice-details { display: flex; justify-content: space-between; margin-bottom: 30px; gap: 40px; }
          .section { margin-bottom: 20px; }
          .section h3 { color: #2563eb; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; }
          .section p { margin: 5px 0; font-size: 14px; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th { background: #2563eb; color: white; padding: 14px; text-align: left; font-weight: 600; font-size: 13px; }
          td { padding: 14px; text-align: left; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
          tr:hover { background: #f9fafb; }
          .text-right { text-align: right; }
          .total-section { margin-top: 30px; text-align: right; padding: 20px; background: #f8fafc; border-radius: 8px; }
          .total-section p { margin: 8px 0; font-size: 15px; }
          .total-section .grand-total { font-size: 22px; font-weight: bold; color: #2563eb; margin-top: 10px; padding-top: 10px; border-top: 2px solid #2563eb; }
          .footer { margin-top: 40px; text-align: center; color: #666; font-size: 13px; padding-top: 20px; border-top: 1px solid #e5e7eb; }
          .status { display: inline-block; padding: 6px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
          .status-paid { background: #dcfce7; color: #166534; }
          .status-pending { background: #fef3c7; color: #92400e; }
          .status-failed { background: #fee2e2; color: #991b1b; }
          .print-btn { 
            display: inline-block; 
            padding: 12px 24px; 
            background: #2563eb; 
            color: white; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            margin-top: 20px;
          }
          .print-btn:hover { background: #1d4ed8; }
          @media print {
            body { background: white; padding: 0; }
            .invoice-container { box-shadow: none; padding: 20px; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="invoice-container">
          <div class="header">
            <h1>${settings.store_name}</h1>
            <p>${settings.phone} | ${settings.email}</p>
            ${settings.address ? `<p>${settings.address}</p>` : ''}
          </div>
          
          <div class="invoice-details">
            <div class="section">
              <h3>Bill To</h3>
              <p><strong>${order.customer_name}</strong></p>
              <p>${order.customer_email}</p>
              <p>${order.customer_phone}</p>
              <p style="margin-top: 10px; white-space: pre-line;">${order.shipping_address}</p>
            </div>
            <div class="section">
              <h3>Invoice Details</h3>
              <p><strong>Invoice #:</strong> ${order.order_number}</p>
              <p><strong>Date:</strong> ${new Date(order.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
              <p><strong>Payment Status:</strong> <span class="status status-${order.payment_status}">${order.payment_status}</span></p>
              <p><strong>Order Status:</strong> ${order.order_status}</p>
            </div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th class="text-right">Quantity</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(item => `
                <tr>
                  <td>${item.phone_name}</td>
                  <td class="text-right">${item.quantity}</td>
                  <td class="text-right">${settings.currency} ${item.unit_price.toLocaleString()}</td>
                  <td class="text-right">${settings.currency} ${item.total_price.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div class="total-section">
            <p><strong>Subtotal:</strong> ${settings.currency} ${order.total_amount.toLocaleString()}</p>
            <p><strong>Shipping:</strong> ${settings.currency} 0</p>
            <p><strong>Tax:</strong> ${settings.currency} 0</p>
            <p class="grand-total"><strong>Total:</strong> ${settings.currency} ${order.total_amount.toLocaleString()}</p>
          </div>
          
          <div class="footer">
            <p><strong>Thank you for shopping with ${settings.store_name}!</strong></p>
            <p style="margin-top: 10px;">For inquiries, contact us at ${settings.phone} or ${settings.email}</p>
          </div>
          
          <div class="no-print" style="text-align: center;">
            <button class="print-btn" onclick="window.print()">
              🖨️ Print Invoice
            </button>
          </div>
        </div>
      </body>
      </html>
    `;
    
    res.send(invoiceHtml);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============ SERVE FRONTEND ============

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve React app for all other routes
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, '../dist', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log('╔════════════════════════════════════════════════════════╗');
  console.log('║     Huzaifa Mobile Store - Server Started              ║');
  console.log('╠════════════════════════════════════════════════════════╣');
  console.log(`║  Port: ${PORT}                                          ║`);
  console.log(`║  API: http://localhost:${PORT}/api                     ║`);
  console.log('║                                                        ║');
  console.log('║  Default Admin Login:                                  ║');
  console.log('║  Email: admin@huzaifastore.com                         ║');
  console.log('║  Password: admin123                                    ║');
  console.log('╚════════════════════════════════════════════════════════╝');
});

export default app;
