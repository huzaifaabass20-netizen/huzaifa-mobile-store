import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, 'data', 'store.db');
const dataDir = path.join(__dirname, 'data');

// Ensure data directory exists
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(dbPath);

// Enable foreign keys
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Initialize database tables
function initDatabase() {
  // Settings table (store name, contact info)
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      store_name TEXT DEFAULT 'Huzaifa Mobile Store',
      phone TEXT DEFAULT '0703609419',
      email TEXT DEFAULT 'huzaifaabass7@gmail.com',
      address TEXT DEFAULT '',
      currency TEXT DEFAULT 'UGX',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Users table (customers and admins)
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'customer' CHECK (role IN ('admin', 'customer')),
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Phones/Products table
  db.exec(`
    CREATE TABLE IF NOT EXISTS phones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      brand TEXT NOT NULL,
      model TEXT NOT NULL,
      description TEXT,
      price REAL NOT NULL,
      original_price REAL,
      stock INTEGER DEFAULT 0,
      image_url TEXT,
      specifications TEXT,
      is_active INTEGER DEFAULT 1,
      is_featured INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Orders table
  db.exec(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE NOT NULL,
      user_id INTEGER,
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      shipping_address TEXT NOT NULL,
      total_amount REAL NOT NULL,
      payment_method TEXT DEFAULT 'flutterwave',
      payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
      payment_reference TEXT,
      order_status TEXT DEFAULT 'pending' CHECK (order_status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
      flutterwave_tx_ref TEXT,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Order items table
  db.exec(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      phone_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      total_price REAL NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (phone_id) REFERENCES phones(id)
    )
  `);

  // Cart table (for logged-in users)
  db.exec(`
    CREATE TABLE IF NOT EXISTS cart (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      phone_id INTEGER NOT NULL,
      quantity INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (phone_id) REFERENCES phones(id),
      UNIQUE(user_id, phone_id)
    )
  `);

  // Insert default settings if not exists
  const settingsStmt = db.prepare('SELECT id FROM settings WHERE id = 1');
  const settings = settingsStmt.get();
  
  if (!settings) {
    const insertSettings = db.prepare(`
      INSERT INTO settings (id, store_name, phone, email)
      VALUES (1, 'Huzaifa Mobile Store', '0703609419', 'huzaifaabass7@gmail.com')
    `);
    insertSettings.run();
  }

  // Insert default admin if not exists
  const adminStmt = db.prepare('SELECT id FROM users WHERE role = ?');
  const admin = adminStmt.get('admin');
  
  if (!admin) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const insertAdmin = db.prepare(`
      INSERT INTO users (name, email, phone, password, role)
      VALUES (?, ?, ?, ?, ?)
    `);
    insertAdmin.run('Administrator', 'admin@huzaifastore.com', '0703609419', hashedPassword, 'admin');
  }

  // Insert sample phones if none exist
  const phoneStmt = db.prepare('SELECT COUNT(*) as count FROM phones');
  const phoneCount = phoneStmt.get();
  
  if (phoneCount.count === 0) {
    const samplePhones = [
      {
        name: 'iPhone 15 Pro Max',
        brand: 'Apple',
        model: 'iPhone 15 Pro Max',
        description: 'The most advanced iPhone with A17 Pro chip, titanium design, and 48MP camera system.',
        price: 4500000,
        original_price: 4800000,
        stock: 15,
        image_url: 'https://images.unsplash.com/photo-1696446701796-da61225697cc?w=500',
        specifications: JSON.stringify({
          display: '6.7" Super Retina XDR',
          processor: 'A17 Pro',
          ram: '8GB',
          storage: '256GB',
          battery: '4422 mAh',
          camera: '48MP Main + 12MP Ultra Wide + 12MP Telephoto'
        }),
        is_featured: 1
      },
      {
        name: 'Samsung Galaxy S24 Ultra',
        brand: 'Samsung',
        model: 'Galaxy S24 Ultra',
        description: 'Galaxy AI is here. Experience the future with S Pen and 200MP camera.',
        price: 3800000,
        original_price: 4200000,
        stock: 20,
        image_url: 'https://images.unsplash.com/photo-1610945265078-3858a0828671?w=500',
        specifications: JSON.stringify({
          display: '6.8" QHD+ AMOLED',
          processor: 'Snapdragon 8 Gen 3',
          ram: '12GB',
          storage: '256GB',
          battery: '5000 mAh',
          camera: '200MP Main + 50MP Telephoto + 12MP Ultra Wide'
        }),
        is_featured: 1
      },
      {
        name: 'Google Pixel 8 Pro',
        brand: 'Google',
        model: 'Pixel 8 Pro',
        description: 'The only phone engineered by Google. Best-in-class AI camera features.',
        price: 3200000,
        original_price: 3500000,
        stock: 12,
        image_url: 'https://images.unsplash.com/photo-1598327775663-6c1c0527d6ad?w=500',
        specifications: JSON.stringify({
          display: '6.7" LTPO OLED',
          processor: 'Google Tensor G3',
          ram: '12GB',
          storage: '128GB',
          battery: '5050 mAh',
          camera: '50MP Main + 48MP Telephoto + 48MP Ultra Wide'
        }),
        is_featured: 1
      },
      {
        name: 'Xiaomi 14 Ultra',
        brand: 'Xiaomi',
        model: '14 Ultra',
        description: 'Leica optics meet cutting-edge technology. Professional photography in your pocket.',
        price: 2800000,
        original_price: 3100000,
        stock: 18,
        image_url: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500',
        specifications: JSON.stringify({
          display: '6.73" AMOLED',
          processor: 'Snapdragon 8 Gen 3',
          ram: '16GB',
          storage: '512GB',
          battery: '5000 mAh',
          camera: '50MP Main + 50MP Telephoto + 50MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'OnePlus 12',
        brand: 'OnePlus',
        model: '12',
        description: 'Smooth beyond belief with 120Hz display and super-fast charging.',
        price: 2400000,
        original_price: 2700000,
        stock: 25,
        image_url: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=500',
        specifications: JSON.stringify({
          display: '6.82" AMOLED',
          processor: 'Snapdragon 8 Gen 3',
          ram: '12GB',
          storage: '256GB',
          battery: '5400 mAh',
          camera: '50MP Main + 64MP Telephoto + 48MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'iPhone 14',
        brand: 'Apple',
        model: 'iPhone 14',
        description: 'A magical new way to interact with iPhone. Vital safety features.',
        price: 2800000,
        original_price: 3200000,
        stock: 30,
        image_url: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=500',
        specifications: JSON.stringify({
          display: '6.1" Super Retina XDR',
          processor: 'A15 Bionic',
          ram: '6GB',
          storage: '128GB',
          battery: '3279 mAh',
          camera: '12MP Main + 12MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'Samsung Galaxy A54 5G',
        brand: 'Samsung',
        model: 'Galaxy A54 5G',
        description: 'Awesome screen, awesome camera, long-lasting battery life.',
        price: 1200000,
        original_price: 1400000,
        stock: 35,
        image_url: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=500',
        specifications: JSON.stringify({
          display: '6.4" Super AMOLED',
          processor: 'Exynos 1380',
          ram: '8GB',
          storage: '128GB',
          battery: '5000 mAh',
          camera: '50MP Main + 12MP Ultra Wide + 5MP Macro'
        }),
        is_featured: 0
      },
      {
        name: 'Tecno Phantom V Fold',
        brand: 'Tecno',
        model: 'Phantom V Fold',
        description: 'Tecno\'s first foldable phone with impressive specs at an affordable price.',
        price: 3200000,
        original_price: 3500000,
        stock: 8,
        image_url: 'https://images.unsplash.com/photo-1660463976-46c02970fd21?w=500',
        specifications: JSON.stringify({
          display: '7.85" LTPO AMOLED Foldable',
          processor: 'Dimensity 9000+',
          ram: '12GB',
          storage: '256GB',
          battery: '5000 mAh',
          camera: '50MP Main + 50MP Telephoto + 13MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'Infinix Zero 30 5G',
        brand: 'Infinix',
        model: 'Zero 30 5G',
        description: 'Premium design with 108MP camera and 144Hz AMOLED display.',
        price: 950000,
        original_price: 1100000,
        stock: 22,
        image_url: 'https://images.unsplash.com/photo-1598327775663-6c1c0527d6ad?w=500',
        specifications: JSON.stringify({
          display: '6.78" AMOLED 144Hz',
          processor: 'Dimensity 8020',
          ram: '12GB',
          storage: '256GB',
          battery: '5000 mAh',
          camera: '108MP Main + 13MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'iPhone 13',
        brand: 'Apple',
        model: 'iPhone 13',
        description: 'The most advanced dual-camera system ever on iPhone.',
        price: 2200000,
        original_price: 2600000,
        stock: 18,
        image_url: 'https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=500',
        specifications: JSON.stringify({
          display: '6.1" Super Retina XDR',
          processor: 'A15 Bionic',
          ram: '4GB',
          storage: '128GB',
          battery: '3227 mAh',
          camera: '12MP Main + 12MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'Samsung Galaxy Z Flip 5',
        brand: 'Samsung',
        model: 'Galaxy Z Flip 5',
        description: 'The pocket-sized foldable phone with a massive cover screen.',
        price: 2800000,
        original_price: 3200000,
        stock: 10,
        image_url: 'https://images.unsplash.com/photo-1660463976-46c02970fd21?w=500',
        specifications: JSON.stringify({
          display: '6.7" Foldable AMOLED',
          processor: 'Snapdragon 8 Gen 2',
          ram: '8GB',
          storage: '256GB',
          battery: '3700 mAh',
          camera: '12MP Main + 12MP Ultra Wide'
        }),
        is_featured: 0
      },
      {
        name: 'Redmi Note 13 Pro+',
        brand: 'Xiaomi',
        model: 'Redmi Note 13 Pro+',
        description: '200MP camera with OIS and 120W hypercharge.',
        price: 1100000,
        original_price: 1300000,
        stock: 28,
        image_url: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500',
        specifications: JSON.stringify({
          display: '6.67" AMOLED 120Hz',
          processor: 'Dimensity 7200-Ultra',
          ram: '8GB',
          storage: '256GB',
          battery: '5000 mAh',
          camera: '200MP Main + 8MP Ultra Wide + 2MP Macro'
        }),
        is_featured: 0
      }
    ];

    const insertPhone = db.prepare(`
      INSERT INTO phones (name, brand, model, description, price, original_price, stock, image_url, specifications, is_featured)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    samplePhones.forEach(phone => {
      insertPhone.run(
        phone.name,
        phone.brand,
        phone.model,
        phone.description,
        phone.price,
        phone.original_price,
        phone.stock,
        phone.image_url,
        phone.specifications,
        phone.is_featured
      );
    });
  }

  console.log('Database initialized successfully');
}

// Initialize database
initDatabase();

export default db;
