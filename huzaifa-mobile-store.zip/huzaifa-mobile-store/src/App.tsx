import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation, useParams } from 'react-router-dom';
import { 
  ShoppingCart, User, Menu, X, Phone, Mail, Search, 
  Package, LogOut, Settings, BarChart3, Plus, 
  Edit, Trash2, Eye, CheckCircle, AlertCircle, ChevronLeft,
  CreditCard, MessageCircle, Printer, Truck, PackageCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Toaster, toast } from 'sonner';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { CartProvider, useCart } from '@/contexts/CartContext';
import { SettingsProvider, useSettings } from '@/contexts/SettingsContext';
import { 
  phonesApi, ordersApi, adminApi, settingsApi, getInvoiceUrl 
} from '@/services/api';

// ==================== TYPES ====================

interface Phone {
  id: number;
  name: string;
  brand: string;
  model: string;
  description: string;
  price: number;
  original_price?: number;
  stock: number;
  image_url: string;
  specifications: Record<string, string>;
  is_featured: boolean;
}

interface Order {
  id: number;
  order_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  total_amount: number;
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  order_status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  created_at: string;
  items: OrderItem[];
}

interface OrderItem {
  id: number;
  phone_id: number;
  phone_name: string;
  phone_image: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

// ==================== COMPONENTS ====================

// Navbar Component
function Navbar() {
  const { isAuthenticated, isAdmin, logout } = useAuth();
  const { itemCount } = useCart();
  const { settings } = useSettings();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-white border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Phone className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900 hidden sm:block">{settings.store_name}</span>
          </Link>

          {/* Search Bar - Desktop */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search phones..."
                className="pl-10 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </form>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/">
              <Button variant="ghost" size="sm">Home</Button>
            </Link>
            <Link to="/track">
              <Button variant="ghost" size="sm">Track Order</Button>
            </Link>
            
            {isAuthenticated ? (
              <>
                {!isAdmin && (
                  <Link to="/cart">
                    <Button variant="ghost" size="sm" className="relative">
                      <ShoppingCart className="w-5 h-5" />
                      {itemCount > 0 && (
                        <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                          {itemCount}
                        </Badge>
                      )}
                    </Button>
                  </Link>
                )}
                
                {isAdmin ? (
                  <Link to="/admin">
                    <Button variant="default" size="sm">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Admin
                    </Button>
                  </Link>
                ) : (
                  <Link to="/account">
                    <Button variant="ghost" size="sm">
                      <User className="w-5 h-5" />
                    </Button>
                  </Link>
                )}
                
                <Button variant="ghost" size="sm" onClick={logout}>
                  <LogOut className="w-5 h-5" />
                </Button>
              </>
            ) : (
              <Link to="/login">
                <Button variant="default" size="sm">Login</Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <form onSubmit={handleSearch} className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Search phones..."
                  className="pl-10 w-full"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </form>
            
            <div className="space-y-2">
              <Link to="/" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start">Home</Button>
              </Link>
              <Link to="/track" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start">Track Order</Button>
              </Link>
              
              {isAuthenticated ? (
                <>
                  {!isAdmin && (
                    <Link to="/cart" onClick={() => setIsMenuOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start">
                        Cart ({itemCount})
                      </Button>
                    </Link>
                  )}
                  {isAdmin ? (
                    <Link to="/admin" onClick={() => setIsMenuOpen(false)}>
                      <Button variant="default" className="w-full justify-start">Admin Dashboard</Button>
                    </Link>
                  ) : (
                    <Link to="/account" onClick={() => setIsMenuOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start">My Account</Button>
                    </Link>
                  )}
                  <Button variant="ghost" className="w-full justify-start" onClick={logout}>
                    Logout
                  </Button>
                </>
              ) : (
                <Link to="/login" onClick={() => setIsMenuOpen(false)}>
                  <Button variant="default" className="w-full">Login</Button>
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

// Footer Component
function Footer() {
  const { settings } = useSettings();

  return (
    <footer className="bg-gray-900 text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">{settings.store_name}</span>
            </div>
            <p className="text-gray-400 text-sm">
              Your trusted source for the latest smartphones at competitive prices.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link to="/" className="hover:text-white">Home</Link></li>
              <li><Link to="/track" className="hover:text-white">Track Order</Link></li>
              <li><Link to="/login" className="hover:text-white">Login</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                {settings.phone}
              </li>
              <li className="flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                {settings.email}
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Payment Methods</h3>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <CreditCard className="w-5 h-5" />
              <span>MTN Mobile Money</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400 mt-2">
              <CreditCard className="w-5 h-5" />
              <span>Airtel Money</span>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} {settings.store_name}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

// Phone Card Component
function PhoneCard({ phone }: { phone: Phone }) {
  const { addToCart } = useCart();
  const { settings } = useSettings();
  const { isAuthenticated, isAdmin } = useAuth();
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = async () => {
    setIsAdding(true);
    try {
      await addToCart(phone.id, 1);
    } finally {
      setIsAdding(false);
    }
  };

  const whatsappLink = `https://wa.me/256${settings.phone.replace(/^0/, '')}?text=I'm%20interested%20in%20buying%20${encodeURIComponent(phone.name)}%20at%20UGX%20${phone.price.toLocaleString()}`;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={phone.image_url || '/placeholder-phone.jpg'}
          alt={phone.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform"
        />
        {phone.original_price && phone.original_price > phone.price && (
          <Badge className="absolute top-2 left-2 bg-red-500">
            Sale
          </Badge>
        )}
        {phone.stock < 5 && phone.stock > 0 && (
          <Badge className="absolute top-2 right-2 bg-orange-500">
            Low Stock
          </Badge>
        )}
        {phone.stock === 0 && (
          <Badge className="absolute top-2 right-2 bg-gray-500">
            Out of Stock
          </Badge>
        )}
      </div>
      
      <CardContent className="p-4">
        <p className="text-sm text-blue-600 font-medium">{phone.brand}</p>
        <h3 className="font-semibold text-lg mb-1 line-clamp-1">{phone.name}</h3>
        <p className="text-gray-500 text-sm line-clamp-2 mb-3">{phone.description}</p>
        
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-gray-900">
              {settings.currency} {phone.price.toLocaleString()}
            </span>
            {phone.original_price && phone.original_price > phone.price && (
              <span className="text-sm text-gray-400 line-through ml-2">
                {settings.currency} {phone.original_price.toLocaleString()}
              </span>
            )}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0 flex gap-2">
        {isAuthenticated && !isAdmin && phone.stock > 0 && (
          <Button 
            className="flex-1" 
            onClick={handleAddToCart}
            disabled={isAdding}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        )}
        
        <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
          <Button variant="outline" className="bg-green-50 border-green-200 hover:bg-green-100">
            <MessageCircle className="w-4 h-4 text-green-600" />
          </Button>
        </a>
        
        <Link to={`/phone/${phone.id}`}>
          <Button variant="outline">
            <Eye className="w-4 h-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

// ==================== PAGES ====================

// Home Page
function HomePage() {
  const [phones, setPhones] = useState<Phone[]>([]);
  const [brands, setBrands] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBrand, setSelectedBrand] = useState('');
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search') || '';

  useEffect(() => {
    fetchPhones();
    fetchBrands();
  }, [selectedBrand, searchQuery]);

  const fetchPhones = async () => {
    setIsLoading(true);
    try {
      const params: Record<string, string> = {};
      if (selectedBrand) params.brand = selectedBrand;
      if (searchQuery) params.search = searchQuery;
      
      const data = await phonesApi.getAll(params);
      setPhones(data);
    } catch (error) {
      toast.error('Failed to load phones');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchBrands = async () => {
    try {
      const data = await phonesApi.getBrands();
      setBrands(data);
    } catch (error) {
      console.error('Failed to load brands');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Latest Smartphones at Best Prices
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Discover the newest iPhone, Samsung, Google Pixel and more
            </p>
            <div className="flex justify-center gap-4">
              <Link to="/#products">
                <Button size="lg" variant="secondary">
                  Shop Now
                </Button>
              </Link>
              <a href={`https://wa.me/256703609419`} target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Chat on MessageCircle
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Products Section */}
      <div id="products" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <h2 className="text-2xl font-bold">
            {searchQuery ? `Search: "${searchQuery}"` : 'All Phones'}
          </h2>
          
          <Select value={selectedBrand} onValueChange={setSelectedBrand}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by brand" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Brands</SelectItem>
              {brands.map(brand => (
                <SelectItem key={brand} value={brand}>{brand}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Products Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-square bg-gray-200" />
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-1/3 mb-2" />
                  <div className="h-6 bg-gray-200 rounded w-3/4 mb-2" />
                  <div className="h-4 bg-gray-200 rounded w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : phones.length === 0 ? (
          <div className="text-center py-16">
            <Package className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No phones found</h3>
            <p className="text-gray-500">Try adjusting your search or filter</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {phones.map(phone => (
              <PhoneCard key={phone.id} phone={phone} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Phone Detail Page
function PhoneDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [phone, setPhone] = useState<Phone | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { addToCart } = useCart();
  const { settings } = useSettings();
  const { isAuthenticated, isAdmin } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPhone();
  }, [id]);

  const fetchPhone = async () => {
    try {
      const data = await phonesApi.getById(Number(id));
      setPhone(data);
    } catch (error) {
      toast.error('Failed to load phone details');
      navigate('/');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (phone) {
      await addToCart(phone.id, quantity);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-4" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="aspect-square bg-gray-200 rounded-lg" />
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4" />
                <div className="h-6 bg-gray-200 rounded w-1/4" />
                <div className="h-4 bg-gray-200 rounded w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!phone) return null;

  const whatsappLink = `https://wa.me/256${settings.phone.replace(/^0/, '')}?text=I'm%20interested%20in%20buying%20${encodeURIComponent(phone.name)}%20at%20UGX%20${phone.price.toLocaleString()}`;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ChevronLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Image */}
          <div className="aspect-square bg-white rounded-lg overflow-hidden shadow-sm">
            <img
              src={phone.image_url}
              alt={phone.name}
              className="w-full h-full object-contain p-8"
            />
          </div>

          {/* Details */}
          <div>
            <p className="text-blue-600 font-medium">{phone.brand}</p>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{phone.name}</h1>
            
            <div className="flex items-baseline gap-4 mb-6">
              <span className="text-3xl font-bold text-gray-900">
                {settings.currency} {phone.price.toLocaleString()}
              </span>
              {phone.original_price && phone.original_price > phone.price && (
                <span className="text-xl text-gray-400 line-through">
                  {settings.currency} {phone.original_price.toLocaleString()}
                </span>
              )}
            </div>

            <p className="text-gray-600 mb-6">{phone.description}</p>

            {/* Specifications */}
            {phone.specifications && (
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Specifications</h3>
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(phone.specifications).map(([key, value]) => (
                    <div key={key} className="bg-gray-100 p-3 rounded">
                      <p className="text-xs text-gray-500 uppercase">{key}</p>
                      <p className="font-medium">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Stock */}
            <div className="mb-6">
              <p className="text-sm">
                Availability: 
                <span className={phone.stock > 0 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'}>
                  {phone.stock > 0 ? `In Stock (${phone.stock} available)` : 'Out of Stock'}
                </span>
              </p>
            </div>

            {/* Actions */}
            {isAuthenticated && !isAdmin && phone.stock > 0 && (
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center border rounded-lg">
                  <button
                    className="px-4 py-2 hover:bg-gray-100"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    -
                  </button>
                  <span className="px-4 py-2 font-medium">{quantity}</span>
                  <button
                    className="px-4 py-2 hover:bg-gray-100"
                    onClick={() => setQuantity(Math.min(phone.stock, quantity + 1))}
                  >
                    +
                  </button>
                </div>
                <Button size="lg" className="flex-1" onClick={handleAddToCart}>
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Add to Cart
                </Button>
              </div>
            )}

            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="lg" className="w-full bg-green-50 border-green-200 hover:bg-green-100">
                <MessageCircle className="w-5 h-5 mr-2 text-green-600" />
                Buy on MessageCircle
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

// Cart Page
function CartPage() {
  const { items, totalAmount, updateQuantity, removeFromCart } = useCart();
  const { settings } = useSettings();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <ShoppingCart className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-6">Add some phones to get started</p>
          <Link to="/">
            <Button>Continue Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-4 flex items-center gap-4">
                  <img
                    src={item.image_url}
                    alt={item.name}
                    className="w-24 h-24 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.name}</h3>
                    <p className="text-blue-600 font-medium">
                      {settings.currency} {item.price.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      -
                    </button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <button
                      className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      +
                    </button>
                  </div>
                  <div className="text-right min-w-[100px]">
                    <p className="font-semibold">
                      {settings.currency} {(item.price * item.quantity).toLocaleString()}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFromCart(item.id)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>{settings.currency} {totalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span>Free</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>{settings.currency} {totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={() => navigate('/checkout')}
                >
                  Proceed to Checkout
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Checkout Page
function CheckoutPage() {
  const { items, totalAmount, clearCart } = useCart();
  const { user } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: user?.name || '',
    customer_email: user?.email || '',
    customer_phone: user?.phone || '',
    shipping_address: ''
  });

  useEffect(() => {
    if (items.length === 0) {
      navigate('/cart');
    }
  }, [items, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const orderData = {
        ...formData,
        items: items.map(item => ({
          phone_id: item.phone_id,
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity
        })),
        total_amount: totalAmount
      };

      const response = await ordersApi.create(orderData);
      
      toast.success('Order placed successfully!');
      await clearCart();
      
      // Redirect to payment or order confirmation
      navigate(`/order-confirmation/${response.order.id}`);
    } catch (error: any) {
      toast.error(error.message || 'Failed to place order');
    } finally {
      setIsProcessing(false);
    }
  };

  if (items.length === 0) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold mb-8">Checkout</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Checkout Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Shipping Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.customer_name}
                      onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.customer_email}
                      onChange={(e) => setFormData({ ...formData, customer_email: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.customer_phone}
                      onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Shipping Address</Label>
                    <Textarea
                      id="address"
                      value={formData.shipping_address}
                      onChange={(e) => setFormData({ ...formData, shipping_address: e.target.value })}
                      required
                      rows={3}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    size="lg"
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'Processing...' : `Pay ${settings.currency} ${totalAmount.toLocaleString()}`}
                  </Button>

                  <p className="text-sm text-gray-500 text-center">
                    You will be redirected to complete payment with MTN Mobile Money or Airtel Money
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-medium">
                        {settings.currency} {(item.price * item.quantity).toLocaleString()}
                      </p>
                    </div>
                  ))}
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span>{settings.currency} {totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mt-4 flex items-center justify-center gap-4 text-sm text-gray-500">
              <div className="flex items-center">
                <CreditCard className="w-4 h-4 mr-1" />
                MTN MoMo
              </div>
              <div className="flex items-center">
                <CreditCard className="w-4 h-4 mr-1" />
                Airtel Money
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Order Confirmation Page
function OrderConfirmationPage() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const { settings } = useSettings();
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrder();
  }, [id]);

  const fetchOrder = async () => {
    try {
      const data = await ordersApi.getById(Number(id));
      setOrder(data);
    } catch (error) {
      toast.error('Failed to load order');
      navigate('/');
    }
  };

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 py-16 text-center">
        <div className="animate-pulse">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-2xl mx-auto px-4 text-center">
        <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
        <h1 className="text-3xl font-bold mb-2">Order Placed Successfully!</h1>
        <p className="text-gray-600 mb-8">
          Thank you for your order. We will contact you shortly to confirm payment.
        </p>

        <Card className="text-left mb-8">
          <CardHeader>
            <CardTitle>Order Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span className="text-gray-600">Order Number</span>
              <span className="font-medium">{order.order_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Total Amount</span>
              <span className="font-medium">
                {settings.currency} {order.total_amount.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Payment Status</span>
              <Badge variant={order.payment_status === 'paid' ? 'default' : 'secondary'}>
                {order.payment_status}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Order Status</span>
              <Badge variant="outline">{order.order_status}</Badge>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/">
            <Button variant="outline">Continue Shopping</Button>
          </Link>
          <a 
            href={getInvoiceUrl(order.id)} 
            target="_blank" 
            rel="noopener noreferrer"
          >
            <Button>
              <Printer className="w-4 h-4 mr-2" />
              View Invoice
            </Button>
          </a>
        </div>
      </div>
    </div>
  );
}

// Login Page
function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const { login, register, isAuthenticated, isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate(isAdmin ? '/admin' : '/');
    }
  }, [isAuthenticated, isAdmin, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isLogin) {
        await login(formData.email, formData.password);
      } else {
        await register(formData.name, formData.email, formData.phone, formData.password);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-md mx-auto px-4">
        <Card>
          <CardHeader className="text-center">
            <CardTitle>{isLogin ? 'Welcome Back' : 'Create Account'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required={!isLogin}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required={!isLogin}
                    />
                  </div>
                </>
              )}
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Please wait...' : (isLogin ? 'Login' : 'Register')}
              </Button>
            </form>

            <p className="text-center mt-4 text-sm text-gray-600">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                className="text-blue-600 ml-1 hover:underline"
                onClick={() => setIsLogin(!isLogin)}
              >
                {isLogin ? 'Register' : 'Login'}
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Account Page
function AccountPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { settings } = useSettings();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const data = await ordersApi.getAll();
      setOrders(data);
    } catch (error) {
      toast.error('Failed to load orders');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold mb-8">My Account</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Profile */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{user?.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{user?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Phone</p>
                  <p className="font-medium">{user?.phone}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Orders */}
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>My Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="animate-pulse space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-16 bg-gray-200 rounded" />
                    ))}
                  </div>
                ) : orders.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500">No orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{order.order_number}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(order.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">
                              {settings.currency} {order.total_amount.toLocaleString()}
                            </p>
                            <Badge variant={order.payment_status === 'paid' ? 'default' : 'secondary'}>
                              {order.payment_status}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-2">
                          <a 
                            href={getInvoiceUrl(order.id)} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            <Button variant="outline" size="sm">
                              <Printer className="w-4 h-4 mr-1" />
                              Invoice
                            </Button>
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Track Order Page
function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { settings } = useSettings();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const data = await ordersApi.track(orderNumber);
      setOrder(data);
    } catch (error) {
      toast.error('Order not found');
      setOrder(null);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <AlertCircle className="w-5 h-5" />;
      case 'processing': return <Package className="w-5 h-5" />;
      case 'shipped': return <Truck className="w-5 h-5" />;
      case 'delivered': return <PackageCheck className="w-5 h-5" />;
      default: return <AlertCircle className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-2xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-8">Track Your Order</h1>

        <Card className="mb-8">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="flex gap-4">
              <Input
                placeholder="Enter order number (e.g., ORD-abc123)"
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Searching...' : 'Track'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {order && (
          <Card>
            <CardHeader>
              <CardTitle>Order {order.order_number}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Status Timeline */}
              <div className="flex items-center justify-between">
                {['pending', 'processing', 'shipped', 'delivered'].map((status, index) => {
                  const isActive = ['pending', 'processing', 'shipped', 'delivered'].indexOf(order.order_status) >= index;
                  return (
                    <div key={status} className={`flex flex-col items-center ${isActive ? 'text-blue-600' : 'text-gray-300'}`}>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${isActive ? 'border-blue-600 bg-blue-50' : 'border-gray-300'}`}>
                        {getStatusIcon(status)}
                      </div>
                      <span className="text-xs mt-1 capitalize">{status}</span>
                    </div>
                  );
                })}
              </div>

              <Separator />

              {/* Order Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Customer</p>
                  <p className="font-medium">{order.customer_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total Amount</p>
                  <p className="font-medium">
                    {settings.currency} {order.total_amount.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Payment Status</p>
                  <Badge variant={order.payment_status === 'paid' ? 'default' : 'secondary'}>
                    {order.payment_status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Order Date</p>
                  <p className="font-medium">
                    {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {/* Items */}
              <div>
                <p className="font-medium mb-2">Items</p>
                <div className="space-y-2">
                  {order.items?.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.phone_name} x {item.quantity}</span>
                      <span>{settings.currency} {item.total_price.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              <a 
                href={getInvoiceUrl(order.id)} 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button variant="outline" className="w-full mt-4">
                  <Printer className="w-4 h-4 mr-2" />
                  View Invoice
                </Button>
              </a>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

// Admin Dashboard
function AdminDashboard() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
    }
  }, [isAdmin, navigate]);

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r min-h-screen hidden lg:block">
          <div className="p-4">
            <h2 className="text-lg font-bold mb-6">Admin Panel</h2>
            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center px-4 py-2 rounded-lg ${activeTab === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'}`}
              >
                <BarChart3 className="w-5 h-5 mr-3" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab('phones')}
                className={`w-full flex items-center px-4 py-2 rounded-lg ${activeTab === 'phones' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'}`}
              >
                <Phone className="w-5 h-5 mr-3" />
                Products
              </button>
              <button
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center px-4 py-2 rounded-lg ${activeTab === 'orders' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'}`}
              >
                <Package className="w-5 h-5 mr-3" />
                Orders
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center px-4 py-2 rounded-lg ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-100'}`}
              >
                <Settings className="w-5 h-5 mr-3" />
                Settings
              </button>
            </nav>
          </div>
        </div>

        {/* Mobile Tabs */}
        <div className="lg:hidden fixed top-16 left-0 right-0 bg-white border-b z-40">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="phones">Products</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Content */}
        <div className="flex-1 p-4 lg:p-8 lg:ml-0 mt-12 lg:mt-0">
          {activeTab === 'dashboard' && <DashboardTab />}
          {activeTab === 'phones' && <PhonesTab />}
          {activeTab === 'orders' && <OrdersTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </div>
      </div>
    </div>
  );
}

// Dashboard Tab
function DashboardTab() {
  const [analytics, setAnalytics] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { settings } = useSettings();

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const data = await adminApi.getAnalytics();
      setAnalytics(data);
    } catch (error) {
      toast.error('Failed to load analytics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Dashboard</h2>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">Total Revenue</p>
            <p className="text-2xl font-bold">
              {settings.currency} {analytics?.totalRevenue?.toLocaleString() || 0}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">Total Orders</p>
            <p className="text-2xl font-bold">{analytics?.totalOrders || 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">Today's Orders</p>
            <p className="text-2xl font-bold">{analytics?.todayOrders || 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">Low Stock Items</p>
            <p className="text-2xl font-bold text-orange-600">{analytics?.lowStockCount || 0}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order #</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {analytics?.recentOrders?.map((order: Order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.order_number}</TableCell>
                  <TableCell>{order.customer_name}</TableCell>
                  <TableCell>{settings.currency} {order.total_amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={order.payment_status === 'paid' ? 'default' : 'secondary'}>
                      {order.payment_status}
                    </Badge>
                  </TableCell>
                  <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Phones Tab
function PhonesTab() {
  const [phones, setPhones] = useState<Phone[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingPhone, setEditingPhone] = useState<Phone | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  useEffect(() => {
    fetchPhones();
  }, []);

  const fetchPhones = async () => {
    try {
      const data = await phonesApi.getAll();
      setPhones(data);
    } catch (error) {
      toast.error('Failed to load phones');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this phone?')) return;
    
    try {
      await phonesApi.delete(id);
      toast.success('Phone deleted');
      fetchPhones();
    } catch (error) {
      toast.error('Failed to delete phone');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const data = {
      name: formData.get('name'),
      brand: formData.get('brand'),
      model: formData.get('model'),
      description: formData.get('description'),
      price: Number(formData.get('price')),
      original_price: Number(formData.get('original_price')) || null,
      stock: Number(formData.get('stock')),
      image_url: formData.get('image_url'),
      specifications: {
        display: formData.get('spec_display'),
        processor: formData.get('spec_processor'),
        ram: formData.get('spec_ram'),
        storage: formData.get('spec_storage'),
        battery: formData.get('spec_battery'),
        camera: formData.get('spec_camera')
      }
    };

    try {
      if (editingPhone) {
        await phonesApi.update(editingPhone.id, data);
        toast.success('Phone updated');
      } else {
        await phonesApi.create(data);
        toast.success('Phone created');
      }
      setIsDialogOpen(false);
      setEditingPhone(null);
      fetchPhones();
    } catch (error) {
      toast.error('Failed to save phone');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Products</h2>
        <div className="animate-pulse space-y-4">
          <div className="h-64 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Products</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingPhone(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Phone
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingPhone ? 'Edit Phone' : 'Add New Phone'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Name</Label>
                  <Input name="name" defaultValue={editingPhone?.name} required />
                </div>
                <div>
                  <Label>Brand</Label>
                  <Input name="brand" defaultValue={editingPhone?.brand} required />
                </div>
              </div>
              <div>
                <Label>Model</Label>
                <Input name="model" defaultValue={editingPhone?.model} required />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea name="description" defaultValue={editingPhone?.description} required />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Price</Label>
                  <Input name="price" type="number" defaultValue={editingPhone?.price} required />
                </div>
                <div>
                  <Label>Original Price</Label>
                  <Input name="original_price" type="number" defaultValue={editingPhone?.original_price} />
                </div>
                <div>
                  <Label>Stock</Label>
                  <Input name="stock" type="number" defaultValue={editingPhone?.stock || 0} required />
                </div>
              </div>
              <div>
                <Label>Image URL</Label>
                <Input name="image_url" defaultValue={editingPhone?.image_url} />
              </div>
              <div className="border-t pt-4">
                <p className="font-medium mb-2">Specifications</p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Display</Label>
                    <Input name="spec_display" defaultValue={editingPhone?.specifications?.display} />
                  </div>
                  <div>
                    <Label>Processor</Label>
                    <Input name="spec_processor" defaultValue={editingPhone?.specifications?.processor} />
                  </div>
                  <div>
                    <Label>RAM</Label>
                    <Input name="spec_ram" defaultValue={editingPhone?.specifications?.ram} />
                  </div>
                  <div>
                    <Label>Storage</Label>
                    <Input name="spec_storage" defaultValue={editingPhone?.specifications?.storage} />
                  </div>
                  <div>
                    <Label>Battery</Label>
                    <Input name="spec_battery" defaultValue={editingPhone?.specifications?.battery} />
                  </div>
                  <div>
                    <Label>Camera</Label>
                    <Input name="spec_camera" defaultValue={editingPhone?.specifications?.camera} />
                  </div>
                </div>
              </div>
              <Button type="submit" className="w-full">
                {editingPhone ? 'Update' : 'Create'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Image</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Brand</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {phones.map((phone) => (
                <TableRow key={phone.id}>
                  <TableCell>
                    <img src={phone.image_url} alt={phone.name} className="w-12 h-12 object-cover rounded" />
                  </TableCell>
                  <TableCell>{phone.name}</TableCell>
                  <TableCell>{phone.brand}</TableCell>
                  <TableCell>{phone.price.toLocaleString()}</TableCell>
                  <TableCell>
                    <span className={phone.stock < 5 ? 'text-orange-600 font-medium' : ''}>
                      {phone.stock}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditingPhone(phone);
                          setIsDialogOpen(true);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(phone.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Orders Tab
function OrdersTab() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { settings } = useSettings();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const data = await adminApi.getOrders();
      setOrders(data);
    } catch (error) {
      toast.error('Failed to load orders');
    } finally {
      setIsLoading(false);
    }
  };

  const updateStatus = async (id: number, orderStatus?: string, paymentStatus?: string) => {
    try {
      await adminApi.updateOrderStatus(id, { order_status: orderStatus, payment_status: paymentStatus });
      toast.success('Status updated');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Orders</h2>
        <div className="animate-pulse space-y-4">
          <div className="h-64 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Orders</h2>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order #</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead>Order Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.order_number}</TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{order.customer_name}</p>
                      <p className="text-sm text-gray-500">{order.customer_phone}</p>
                    </div>
                  </TableCell>
                  <TableCell>{settings.currency} {order.total_amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Select 
                      value={order.payment_status} 
                      onValueChange={(value) => updateStatus(order.id, undefined, value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                        <SelectItem value="refunded">Refunded</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select 
                      value={order.order_status} 
                      onValueChange={(value) => updateStatus(order.id, value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="processing">Processing</SelectItem>
                        <SelectItem value="shipped">Shipped</SelectItem>
                        <SelectItem value="delivered">Delivered</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <a 
                      href={getInvoiceUrl(order.id)} 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      <Button variant="ghost" size="sm">
                        <Printer className="w-4 h-4" />
                      </Button>
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Settings Tab
function SettingsTab() {
  const { settings, refreshSettings } = useSettings();
  const [formData, setFormData] = useState(settings);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setFormData(settings);
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      await settingsApi.update(formData);
      toast.success('Settings saved');
      refreshSettings();
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Store Settings</h2>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4 max-w-lg">
            <div>
              <Label>Store Name</Label>
              <Input
                value={formData.store_name}
                onChange={(e) => setFormData({ ...formData, store_name: e.target.value })}
              />
            </div>
            <div>
              <Label>Phone Number</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <Label>Address</Label>
              <Textarea
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            </div>
            <div>
              <Label>Currency</Label>
              <Input
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
              />
            </div>
            <Button type="submit" disabled={isSaving}>
              {isSaving ? 'Saving...' : 'Save Settings'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== MAIN APP ====================

function App() {
  return (
    <AuthProvider>
      <SettingsProvider>
        <CartProvider>
          <Router>
            <div className="min-h-screen flex flex-col">
              <Navbar />
              <main className="flex-1">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/phone/:id" element={<PhoneDetailPage />} />
                  <Route path="/cart" element={<CartPage />} />
                  <Route path="/checkout" element={<CheckoutPage />} />
                  <Route path="/order-confirmation/:id" element={<OrderConfirmationPage />} />
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/account" element={<AccountPage />} />
                  <Route path="/track" element={<TrackOrderPage />} />
                  <Route path="/admin" element={<AdminDashboard />} />
                </Routes>
              </main>
              <Footer />
            </div>
            <Toaster position="top-right" />
          </Router>
        </CartProvider>
      </SettingsProvider>
    </AuthProvider>
  );
}

export default App;
