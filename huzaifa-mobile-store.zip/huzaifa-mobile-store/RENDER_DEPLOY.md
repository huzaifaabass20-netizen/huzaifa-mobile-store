# Deploy on Render - Step by Step Guide

## Quick Deploy (5 minutes)

### Step 1: Prepare Your Project

1. Make sure all files are in the project folder:
   - `server/` - Backend code
   - `src/` - Frontend code
   - `dist/` - Built frontend (already built)
   - `package.json`
   - `.env` (we'll configure this on Render)

### Step 2: Upload to GitHub

1. Go to [github.com](https://github.com) and create an account (if you don't have one)
2. Click the **+** button → **New repository**
3. Name it: `huzaifa-mobile-store`
4. Click **Create repository**
5. Upload your files:
   ```bash
   # In your project folder
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/huzaifa-mobile-store.git
   git push -u origin main
   ```
   
   Or simply drag and drop files using GitHub's web interface.

### Step 3: Deploy on Render

1. Go to [render.com](https://render.com)
2. Click **Sign Up** and choose **Sign up with GitHub**
3. Authorize Render to access your GitHub
4. Click **New** → **Web Service**
5. Find and select your `huzaifa-mobile-store` repository
6. Configure the service:

   | Setting | Value |
   |---------|-------|
   | Name | huzaifa-mobile-store |
   | Runtime | Node |
   | Build Command | `npm install` |
   | Start Command | `npm start` |
   | Plan | Free |

7. Click **Create Web Service**

### Step 4: Add Environment Variables

1. In your Render dashboard, click on your service
2. Go to the **Environment** tab
3. Add the following variables:

   ```
   JWT_SECRET=your-super-secret-key-here-change-this
   EMAIL_USER=huzaifaabass7@gmail.com
   EMAIL_PASS=your-gmail-app-password
   FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-your-key-here
   FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-your-key-here
   BASE_URL=https://huzaifa-mobile-store.onrender.com
   ```

4. Click **Save Changes**

### Step 5: Wait for Deployment

- Render will automatically build and deploy your app
- This takes 2-5 minutes
- You'll see a green "Live" badge when ready
- Your URL will be: `https://huzaifa-mobile-store.onrender.com`

---

## Setting Up Gmail for Email Notifications

### Step 1: Enable 2-Step Verification

1. Go to [myaccount.google.com/security](https://myaccount.google.com/security)
2. Find "2-Step Verification" and click **Turn on**
3. Follow the setup process

### Step 2: Create App Password

1. Go to [myaccount.google.com/security](https://myaccount.google.com/security)
2. Search for "App passwords"
3. Click **App passwords**
4. Select:
   - App: **Mail**
   - Device: **Other (Custom name)** → Type "Huzaifa Store"
5. Click **Generate**
6. Copy the 16-character password (looks like: `abcd efgh ijkl mnop`)
7. Paste this in Render's `EMAIL_PASS` environment variable (without spaces)

---

## Setting Up Flutterwave for Payments

### Step 1: Create Account

1. Go to [flutterwave.com](https://flutterwave.com)
2. Sign up for a business account
3. Complete verification

### Step 2: Get API Keys

1. Login to your Flutterwave dashboard
2. Go to **Settings** → **API**
3. Copy your:
   - **Public Key** (starts with `FLWPUBK_`)
   - **Secret Key** (starts with `FLWSECK_`)
4. Add these to Render's environment variables

### Step 3: Setup Webhook (Optional but Recommended)

1. In Flutterwave dashboard, go to **Settings** → **Webhooks**
2. Add webhook URL: `https://your-app.onrender.com/api/payment/verify`
3. Select events: `charge.completed`

---

## Default Login Credentials

After deployment, you can login with:

### Admin Account
- **Email:** admin@huzaifastore.com
- **Password:** admin123

**Important:** Change the admin password after first login!

---

## Managing Your Store

### Access Admin Dashboard

1. Login with admin credentials
2. Click "Admin" in the navigation
3. You'll see:
   - Dashboard with sales analytics
   - Products management
   - Orders management
   - Store settings

### Edit Store Information

1. Go to Admin → Settings
2. Update:
   - Store Name
   - Phone Number
   - Email
   - Address
   - Currency
3. Click "Save Settings"

### Add New Phones

1. Go to Admin → Products
2. Click "Add Phone"
3. Fill in details:
   - Name, Brand, Model
   - Description
   - Price and Original Price (for discounts)
   - Stock quantity
   - Image URL
   - Specifications
4. Click "Create"

### Manage Orders

1. Go to Admin → Orders
2. View all orders
3. Update payment status (Pending → Paid)
4. Update order status (Pending → Processing → Shipped → Delivered)
5. Click print icon to view invoice

---

## Customer Features

Your customers can:
- Browse phones by brand
- Search phones
- Add to cart
- Checkout with MTN Mobile Money or Airtel Money
- Track orders
- View order history
- Download invoices
- Buy via WhatsApp

---

## Troubleshooting

### App Won't Start

1. Check Render logs (Logs tab)
2. Verify environment variables are set
3. Make sure `npm install` ran successfully

### Emails Not Sending

1. Verify Gmail app password is correct
2. Check `EMAIL_USER` matches your Gmail
3. Check spam folders

### Payments Not Working

1. Verify Flutterwave keys are correct
2. Make sure you're using test keys for testing
3. Switch to live keys for production

---

## Need Help?

Contact:
- Phone: 0703609419
- Email: huzaifaabass7@gmail.com

---

## Next Steps

After successful deployment:

1. ✅ Change admin password
2. ✅ Update store settings
3. ✅ Add your phones
4. ✅ Setup Flutterwave live mode
5. ✅ Test a purchase
6. ✅ Share your store URL!

Your online phone store is now live and ready for business! 🎉
