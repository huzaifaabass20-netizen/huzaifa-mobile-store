const required=['DATABASE_URL','SESSION_SECRET','BASE_URL','ADMIN_USERNAME','ADMIN_PASSWORD','FLW_SECRET_KEY','FLW_SECRET_HASH'];
const missing=required.filter(key=>!process.env[key]||/replace-with|choose-a|your-store|xxxxxxxx/i.test(process.env[key]));
const problems=[];
if(process.env.SESSION_SECRET&&process.env.SESSION_SECRET.length<32)problems.push('SESSION_SECRET must be at least 32 characters');
if(process.env.BASE_URL&&!/^https:\/\//.test(process.env.BASE_URL))problems.push('BASE_URL must begin with https://');
if(missing.length)problems.push(`Set real values for: ${missing.join(', ')}`);
if(problems.length){console.error('Launch preflight failed:\n- '+problems.join('\n- '));process.exit(1)}
console.log('Launch preflight passed. Required deployment values are present.');
