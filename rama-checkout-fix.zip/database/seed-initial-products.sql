-- Initial admin drafts for Huzaifa Phone Store
-- Reference prices were checked from Ugandan retailers on 9 Nov 2026.
-- These are NOT claims of Huzaifa Phone Store inventory. All drafts begin hidden with zero stock.
-- In Admin → Inventory, confirm own price, warranty, colour and quantity, then publish each item.
INSERT INTO products(name,brand,model,description,price,stock_quantity,sku,category,condition,storage,ram,battery,image_url,active) VALUES
('Galaxy A16','Samsung','Galaxy A16','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',736000,0,'HPS-SAM-A16-4-128','Phones','New','128GB','4GB','5000mAh','/images/samsung-galaxy-a16.png',false),
('Spark 30C','Tecno','Spark 30C','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',621000,0,'HPS-TEC-SP30C-8-128','Phones','New','128GB','8GB','5000mAh','/images/tecno-spark-30c.png',false),
('Hot 50i','Infinix','Hot 50i','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',575000,0,'HPS-INF-H50I-8-128','Phones','New','128GB','8GB','5000mAh','/images/infinix-hot-50i.png',false),
('Hot 50 Pro Plus','Infinix','Hot 50 Pro Plus','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',839000,0,'HPS-INF-H50PP-8-128','Phones','New','128GB','8GB','5000mAh','/images/infinix-hot-50i.png',false),
('Redmi Note 14 4G','Xiaomi','Redmi Note 14 4G','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',790000,0,'HPS-XIA-RN14-8-256','Phones','New','256GB','8GB','5110mAh','/images/tecno-spark-30c.png',false),
('Spark 50','Tecno','Spark 50','Draft catalogue item. Confirm own price, warranty, colour and stock before publishing.',671200,0,'HPS-TEC-SP50-4-128','Phones','New','128GB','4GB','','/images/tecno-spark-30c.png',false),
('20W USB-C Fast Charger','Generic','20W USB-C Fast Charger','Draft accessory. Confirm brand, compatibility, warranty, final price and stock before publishing.',25000,0,'HPS-ACC-USBC-20W','Accessories','New','','','','/images/accessories-collection.png',false),
('Braided USB-C Cable','Generic','Braided USB-C Cable','Draft accessory. Confirm connector type, length, warranty, final price and stock before publishing.',15000,0,'HPS-ACC-USBC-CABLE','Accessories','New','','','','/images/accessories-collection.png',false),
('Wireless Earbuds','Generic','Wireless Earbuds','Draft accessory. Confirm model, warranty, final price and stock before publishing.',60000,0,'HPS-ACC-EARBUDS','Accessories','New','','','','/images/accessories-collection.png',false),
('10000mAh Power Bank','Generic','10000mAh Power Bank','Draft accessory. Confirm capacity, fast-charge support, warranty, final price and stock before publishing.',75000,0,'HPS-ACC-PBANK-10K','Accessories','New','','10000mAh','/images/accessories-collection.png',false)
ON CONFLICT (sku) DO NOTHING;
