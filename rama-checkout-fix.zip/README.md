# Huzaifa Phone Store

Production Node/Express + PostgreSQL commerce application with database-owned business settings, secure sessions, protected admin APIs, Flutterwave server-side verification, idempotent webhooks, image processing, invoices and email hooks.

## Local setup
1. Install Node 20+ and PostgreSQL 15+.
2. Copy `.env.example` to `.env`; set a unique `SESSION_SECRET`, database URL and admin credentials.
3. `npm ci`
4. `npm run migrate`
5. `npm run seed-admin`
6. `npm start`, then open `http://localhost:3000`.

## Render deployment
1. Create a private GitHub repository and upload this folder, excluding `.env`.
2. In Render, create a Blueprint and select the repository. `render.yaml` provisions the web service and PostgreSQL.
3. Add `BASE_URL` as the exact Render HTTPS URL, plus `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `FLW_PUBLIC_KEY`, `FLW_SECRET_KEY`, `FLW_SECRET_HASH`; add SMTP values when email is wanted.
4. Deploy. The build runs the migration and safely creates/updates the admin with the configured password.
5. In Flutterwave dashboard set the webhook to `https://YOUR-DOMAIN/flw-webhook`, use the same webhook secret hash as `FLW_SECRET_HASH`, and configure the redirect URL through the store backend.
6. Start with Flutterwave test keys, use a test mobile-money flow, inspect orders/payments, then replace **all** test Flutterwave keys with live keys only after the live webhook is configured.

## Launch checklist
1. Set the Render `BASE_URL` to the final HTTPS address, then run `npm run preflight` with the real deployment values. It never prints the values themselves.
2. Deploy the Blueprint, wait for `/api/health` to return `{"ok":true}`, then sign in using the seeded admin account.
3. Add real products, images, delivery/returns policy and store contact details in Admin before accepting customer orders.
4. In Flutterwave, point the webhook at `https://YOUR-DOMAIN/flw-webhook`; make one **test** MTN and one **test** Airtel payment, confirm the order becomes paid once, stock falls once, the invoice downloads and the customer returns to their orders.
5. Only then replace every Flutterwave test value with its matching live value. Re-run `npm run preflight` and make a small live verification payment.

A `Dockerfile` is included for container hosts; Render remains the configured launch route.

## Payment safety
Checkout derives product prices and inventory from PostgreSQL. A browser never decides a price or marks an order paid. Flutterwave callbacks and webhooks are verified server-side against the transaction API; payment events are persisted for idempotency. Stock is locked and deducted only once after verified payment. Missing stock sends an order to review rather than overselling.

## Tests and operational checks
Run `npm test` and `npm run migrate` before deploy. Test registration/login, catalog filters, cart quantities, checkout rejection for excessive quantity, admin route rejection while logged out, a Flutterwave test payment, its webhook replay, invoice download, and admin stock/order updates. Flutterwave cannot be live-tested without merchant credentials.

## Security
Never commit `.env` or uploads. Use a strong secret, HTTPS, private PostgreSQL, and a restricted Flutterwave webhook hash. Admin routes require an admin session and CSRF token. Uploaded images are MIME-filtered, size-limited and converted to WebP.
