#!/bin/bash

echo "Starting Huzaifa Mobile Store..."
echo "================================"

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Create data directory if not exists
mkdir -p server/data

# Start the server
echo "Starting server on port 3001..."
echo ""
echo "Your store will be available at:"
echo "  - Local: http://localhost:3001"
echo ""
echo "Default Admin Login:"
echo "  Email: admin@huzaifastore.com"
echo "  Password: admin123"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

node server/index.js
