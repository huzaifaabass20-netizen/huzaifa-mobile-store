# Huzaifa Mobile Store - Professional Online Phone Store

A complete, production-ready online phone store with customer storefront, admin dashboard, payment integration, and comprehensive order management.

## Features

### Customer Features
- Browse phones with search and filter by brand
- View detailed product pages with specifications
- Add to cart functionality
- Secure checkout process
- Order tracking (public page - no login required)
- Customer registration/login
- Order history with invoice download
- WhatsApp "Buy Now" integration
- Responsive design for mobile and desktop

### Admin Dashboard
- Secure login system
- Dashboard with analytics:
  - Total revenue
  - Total orders
  - Today's orders & revenue
  - Low stock alerts
  - Recent orders
  - Top selling products
  - Sales by month
- Product management (add, edit, delete)
- Stock management with alerts
- Order management with status updates
- Store settings (edit store name, phone, email, address, currency)
- Professional PDF invoice generation

### Payment Integration
- Flutterwave payment gateway ready
- MTN Mobile Money support
- Airtel Money support
- Payment verification webhook

### Email Notifications
- Welcome email on registration
- Order confirmation email
- Payment confirmation email

## Tech Stack

- **Frontend**: React + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend**: Node.js + Express (ES Modules)
- **Database**: SQLite (better-sqlite3)
- **Authentication**: JWT
- **Email**: Nodemailer (Gmail)

## Default Login Credentials

### Admin Account
- **Email:** admin@huzaifastore.com
- **Password:** admin123

**⚠️ IMPORTANT:** Change the admin password after first login!

## Quick Start

### Option 1: Deploy on Render (Recommended - FREE)

1. **Upload to GitHub**
   - Create a GitHub account at [github.com](https://github.com)
   - Create a new repository named `huzaifa-mobile-store`
   - Upload all files from this folder

2. **Deploy on Render**
   - Go to [render.com](https://render.com)
   - Sign up with GitHub
   - Click **New** → **Web Service**
   - Select your `huzaifa-mobile-store` repository
   - Configure:
     - **Name:** `huzaifa-mobile-store`
     - **Runtime:** Node
     - **Build Command:** `npm install`
     - **Start Command:** `npm start`
     - **Plan:** Free
   - Click **Create Web Service**

3. **Add Environment Variables**
   In your Render dashboard, go to **Environment** tab and add:
   ```
   JWT_SECRET=your-super-secret-key-change-this-in-production
   EMAIL_USER=huzaifaabass7@gmail.com
   EMAIL_PASS=your-gmail-app-password
   FLUTTERWAVE_PUBLIC_KEY=your-flutterwave-public-key
   FLUTTERWAVE_SECRET_KEY=your-flutterwave-secret-key
   BASE_URL=https://your-app-name.onrender.com
   ```

4. **Deploy!**
   - Render will automatically build and deploy
   - Your store will be live at: `https://huzaifa-mobile-store.onrender.com`

### Option 2: Run Locally

```bash
# Install dependencies
npm install

# Start the server
npm start

# Open http://localhost:3001
```

## Setting Up Gmail for Email Notifications

1. **Enable 2-Step Verification**
   - Go to [myaccount.google.com/security](https://myaccount.google.com/security)
   - Find "2-Step Verification" and click **Turn on**
   - Follow the setup process

2. **Create App Password**
   - Go to [myaccount.google.com/security](https://myaccount.google.com/security)
   - Search for "App passwords"
   - Click **App passwords**
   - Select:
     - App: **Mail**
     - Device: **Other (Custom name)** → Type "Huzaifa Store"
   - Click **Generate**
   - Copy the 16-character password (looks like: `abcd efgh ijkl mnop`)
   - Paste this in Render's `EMAIL_PASS` environment variable (without spaces)

## Setting Up Flutterwave for Payments

1. **Create Account**
   - Go to [flutterwave.com](https://flutterwave.com)
   - Sign up for a business account
   - Complete verification

2. **Get API Keys**
   - Login to your Flutterwave dashboard
   - Go to **Settings** → **API**
   - Copy your:
     - **Public Key** (starts with `FLWPUBK_`)
     - **Secret Key** (starts with `FLWSECK_`)
   - Add these to Render's environment variables

3. **Setup Webhook (Optional but Recommended)**
   - In Flutterwave dashboard, go to **Settings** → **Webhooks**
   - Add webhook URL: `https://your-app.onrender.com/api/payment/verify`
   - Select events: `charge.completed`

## Your Business Contact Info

The store is pre-configured with:
- **Store Name:** Huzaifa Mobile Store
- **Phone:** 0703609419
- **Email:** huzaifaabass7@gmail.com
- **Currency:** UGX

You can change all of these in the Admin Dashboard → Settings after logging in.

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user

### Phones
- `GET /api/phones` - List all phones
- `GET /api/phones/:id` - Get phone details
- `POST /api/phones` - Create phone (admin)
- `PUT /api/phones/:id` - Update phone (admin)
- `DELETE /api/phones/:id` - Delete phone (admin)

### Cart
- `GET /api/cart` - Get cart
- `POST /api/cart` - Add to cart
- `PUT /api/cart/:id` - Update quantity
- `DELETE /api/cart/:id` - Remove item

### Orders
- `GET /api/orders` - Get user orders
- `POST /api/orders` - Create order
- `GET /api/orders/:id` - Get order details
- `GET /api/track/:orderNumber` - Track order (public)

### Admin
- `GET /api/admin/analytics` - Dashboard analytics
- `GET /api/admin/orders` - All orders
- `PUT /api/orders/:id/status` - Update order status

### Settings
- `GET /api/settings` - Get store settings
- `PUT /api/settings` - Update settings (admin)

## Project Structure

```
├── server/
│   ├── index.mjs         # Express server with all APIs
│   ├── database.mjs      # SQLite database setup
│   └── data/             # Database files
├── src/
│   ├── contexts/         # React contexts (Auth, Cart, Settings)
│   ├── services/         # API services
│   ├── components/ui/    # 40+ shadcn/ui components
│   └── App.tsx           # Main application
├── dist/                 # Built frontend (ready to deploy)
├── package.json
├── .env                  # Environment variables
└── README.md
```

## Managing Your Store

### Access Admin Dashboard
1. Login with admin credentials
2. Click "Admin" in the navigation
3. You'll see:
   - Dashboard with sales analytics
   - Products management
   - Orders management
   - Store settings

### Edit Store Information
1. Go to Admin → Settings
2. Update:
   - Store Name
   - Phone Number
   - Email
   - Address
   - Currency
3. Click "Save Settings"

### Add New Phones
1. Go to Admin → Products
2. Click "Add Phone"
3. Fill in details:
   - Name, Brand, Model
   - Description
   - Price and Original Price (for discounts)
   - Stock quantity
   - Image URL
   - Specifications
4. Click "Create"

### Manage Orders
1. Go to Admin → Orders
2. View all orders
3. Update payment status (Pending → Paid)
4. Update order status (Pending → Processing → Shipped → Delivered)
5. Click print icon to view invoice

## Troubleshooting

### App Won't Start
1. Check Render logs (Logs tab)
2. Verify environment variables are set
3. Make sure `npm install` ran successfully

### Emails Not Sending
1. Verify Gmail app password is correct
2. Check `EMAIL_USER` matches your Gmail
3. Check spam folders

### Payments Not Working
1. Verify Flutterwave keys are correct
2. Make sure you're using test keys for testing
3. Switch to live keys for production

## Support

For support, contact:
- **Phone:** 0703609419
- **Email:** huzaifaabass7@gmail.com

## License

This project is proprietary software for Huzaifa Mobile Store.
