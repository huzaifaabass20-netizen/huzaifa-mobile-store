const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Helper to get auth token
const getToken = () => localStorage.getItem('token');

// Generic fetch wrapper
async function fetchApi(endpoint: string, options: RequestInit = {}) {
  const url = `${API_URL}${endpoint}`;
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...options.headers as Record<string, string>
  };
  
  const token = getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  const response = await fetch(url, {
    ...options,
    headers
  });
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'An error occurred' }));
    throw new Error(error.error || `HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}

// Settings API
export const settingsApi = {
  get: () => fetchApi('/settings'),
  update: (data: any) => fetchApi('/settings', {
    method: 'PUT',
    body: JSON.stringify(data)
  })
};

// Auth API
export const authApi = {
  register: (data: any) => fetchApi('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  login: (data: any) => fetchApi('/auth/login', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  me: () => fetchApi('/auth/me')
};

// Phones API
export const phonesApi = {
  getAll: (params?: Record<string, string>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return fetchApi(`/phones${queryString}`);
  },
  getById: (id: number) => fetchApi(`/phones/${id}`),
  create: (data: any) => fetchApi('/phones', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  update: (id: number, data: any) => fetchApi(`/phones/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  delete: (id: number) => fetchApi(`/phones/${id}`, {
    method: 'DELETE'
  }),
  getBrands: () => fetchApi('/brands')
};

// Cart API
export const cartApi = {
  get: () => fetchApi('/cart'),
  add: (data: any) => fetchApi('/cart', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  update: (id: number, data: any) => fetchApi(`/cart/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  remove: (id: number) => fetchApi(`/cart/${id}`, {
    method: 'DELETE'
  }),
  clear: () => fetchApi('/cart', {
    method: 'DELETE'
  })
};

// Orders API
export const ordersApi = {
  getAll: () => fetchApi('/orders'),
  getById: (id: number) => fetchApi(`/orders/${id}`),
  create: (data: any) => fetchApi('/orders', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  track: (orderNumber: string) => fetchApi(`/track/${orderNumber}`)
};

// Admin API
export const adminApi = {
  getOrders: (params?: Record<string, string>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return fetchApi(`/admin/orders${queryString}`);
  },
  updateOrderStatus: (id: number, data: any) => fetchApi(`/orders/${id}/status`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  getAnalytics: () => fetchApi('/admin/analytics'),
  getLowStock: () => fetchApi('/admin/low-stock')
};

// Payment API
export const paymentApi = {
  initialize: (data: any) => fetchApi('/payment/initialize', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  verify: (data: any) => fetchApi('/payment/verify', {
    method: 'POST',
    body: JSON.stringify(data)
  })
};

// Invoice API
export const getInvoiceUrl = (orderId: number) => `${API_URL}/invoice/${orderId}`;
