# Huzaifa Mobile Store - Deployment Guide

## 🚀 Quick Start (5 Minutes)

### Step 1: Upload to GitHub

1. Create a GitHub account at [github.com](https://github.com)
2. Create a new repository named `huzaifa-mobile-store`
3. Upload all project files to the repository

### Step 2: Deploy on Render (FREE)

1. Go to [render.com](https://render.com) and sign up with GitHub
2. Click **New** → **Web Service**
3. Select your `huzaifa-mobile-store` repository
4. Configure:
   - **Name**: `huzaifa-mobile-store`
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
5. Click **Create Web Service**

### Step 3: Add Environment Variables

In your Render dashboard, go to **Environment** tab and add:

```
JWT_SECRET=your-super-secret-key-change-this-in-production
EMAIL_USER=huzaifaabass7@gmail.com
EMAIL_PASS=your-gmail-app-password
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-your-key-here
FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-your-key-here
BASE_URL=https://your-app-name.onrender.com
```

### Step 4: Deploy!

- Render will automatically build and deploy
- Your store will be live at: `https://huzaifa-mobile-store.onrender.com`

---

## 📋 Default Login Credentials

### Admin Account
- **Email:** `admin@huzaifastore.com`
- **Password:** `admin123`

**⚠️ IMPORTANT:** Change the admin password after first login!

---

## 🔧 Setting Up Gmail for Email Notifications

### Step 1: Enable 2-Step Verification
1. Go to [myaccount.google.com/security](https://myaccount.google.com/security)
2. Find "2-Step Verification" and click **Turn on**
3. Follow the setup process

### Step 2: Create App Password
1. Go to [myaccount.google.com/security](https://myaccount.google.com/security)
2. Search for "App passwords"
3. Click **App passwords**
4. Select:
   - App: **Mail**
   - Device: **Other (Custom name)** → Type "Huzaifa Store"
5. Click **Generate**
6. Copy the 16-character password (looks like: `abcd efgh ijkl mnop`)
7. Paste this in Render's `EMAIL_PASS` environment variable (without spaces)

---

## 💳 Setting Up Flutterwave for Payments

### Step 1: Create Account
1. Go to [flutterwave.com](https://flutterwave.com)
2. Sign up for a business account
3. Complete verification

### Step 2: Get API Keys
1. Login to your Flutterwave dashboard
2. Go to **Settings** → **API**
3. Copy your:
   - **Public Key** (starts with `FLWPUBK_`)
   - **Secret Key** (starts with `FLWSECK_`)
4. Add these to Render's environment variables

### Step 3: Setup Webhook (Optional but Recommended)
1. In Flutterwave dashboard, go to **Settings** → **Webhooks**
2. Add webhook URL: `https://your-app.onrender.com/api/payment/verify`
3. Select events: `charge.completed`

---

## 🏪 Managing Your Store

### Access Admin Dashboard
1. Login with admin credentials
2. Click "Admin" in the navigation
3. You'll see:
   - Dashboard with sales analytics
   - Products management
   - Orders management
   - Store settings

### Edit Store Information
1. Go to Admin → Settings
2. Update:
   - Store Name
   - Phone Number
   - Email
   - Address
   - Currency
3. Click "Save Settings"

### Add New Phones
1. Go to Admin → Products
2. Click "Add Phone"
3. Fill in details:
   - Name, Brand, Model
   - Description
   - Price and Original Price (for discounts)
   - Stock quantity
   - Image URL
   - Specifications
4. Click "Create"

### Manage Orders
1. Go to Admin → Orders
2. View all orders
3. Update payment status (Pending → Paid)
4. Update order status (Pending → Processing → Shipped → Delivered)
5. Click print icon to view invoice

---

## 📞 Your Business Contact Info

The store is pre-configured with:
- **Phone:** 0703609419
- **Email:** huzaifaabass7@gmail.com
- **Store Name:** Huzaifa Mobile Store

You can change all of these in the Admin Dashboard → Settings after logging in.

---

## 🛠 Running Locally

```bash
# Install dependencies
npm install

# Start the server
npm start

# Or run in development mode
npm run dev
```

Then open http://localhost:3001

---

## ✅ Features Included

### Customer Storefront
- Browse phones with search and filter by brand
- View detailed product pages with specifications
- Add to cart functionality
- Secure checkout process
- Order tracking page
- Customer account registration/login
- Order history with invoice download
- WhatsApp "Buy Now" integration

### Admin Dashboard
- Secure login
- Dashboard with analytics (sales, revenue, stock alerts)
- Add, edit, delete products with stock control
- Order management with status updates
- Store settings (edit store name, contact info)
- PDF invoice generation

### Payment Integration
- Flutterwave payment gateway ready
- MTN Mobile Money support
- Airtel Money support
- Payment verification system

---

## 🐛 Troubleshooting

### App Won't Start
1. Check Render logs (Logs tab)
2. Verify environment variables are set
3. Make sure `npm install` ran successfully

### Emails Not Sending
1. Verify Gmail app password is correct
2. Check `EMAIL_USER` matches your Gmail
3. Check spam folders

### Payments Not Working
1. Verify Flutterwave keys are correct
2. Make sure you're using test keys for testing
3. Switch to live keys for production

---

## 📧 Support

For support, contact:
- **Phone:** 0703609419
- **Email:** huzaifaabass7@gmail.com

---

## 🎉 Next Steps After Deployment

1. ✅ Change admin password
2. ✅ Update store settings
3. ✅ Add your phones
4. ✅ Setup Flutterwave live mode
5. ✅ Test a purchase
6. ✅ Share your store URL!

Your online phone store is now live and ready for business! 🚀
